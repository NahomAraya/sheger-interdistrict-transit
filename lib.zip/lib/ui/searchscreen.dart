// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:sit_user/net/flutterfire.dart';
import 'package:sit_user/ui/busscreen.dart';

Map bus_map = {};
List buses = [];
TextEditingController fromField = TextEditingController();
TextEditingController toField = TextEditingController();

class SearchScreen extends StatefulWidget {
  const SearchScreen({ Key? key }) : super(key: key);

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  List<String?> shift = [
    "morning",
    "afternoon",
    "night"
  ];
  String? dropdownShift = "morning";
  List<String?> stations = [
    "70 Dereja Station",
    "Ayat Station",
    "Bel Air Station",
    "British Embassy Station",
    "Civil Service Station",
    "Gurdshola Station",
    "Kebena Station",
    "Megenagna Station 1",
    "Megenagna Station 2",
    "Meri Station",
    "Piassa Station",
    "Salite Meheret Station",
    "Shola Station",
    "Yetebaberut Station"

  ];
  String? dropdownStationStart = "Megenagna Station 1";
   String? dropdownStationEnd = "Megenagna Station 1";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Express Bus")),
      body: Container(
         width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          color: Colors.blueAccent,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Start Station", style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w500,
              color: Colors.white,
            )),
              DropdownButton(
                        value: dropdownStationStart,
                        onChanged: (String? value) {
                        setState(() {
                              dropdownStationStart = value;
                          });
                           },
                        items: stations.map<DropdownMenuItem<String>>((String? value) {
                        return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value!),
                         );
                       }).toList(),
                       ),
              Text("End Station", style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w500,
              color: Colors.white,
            )),
              DropdownButton(
                        value: dropdownStationEnd,
                        onChanged: (String? value) {
                        setState(() {
                              dropdownStationEnd = value;
                          });
                           },
                        items: stations.map<DropdownMenuItem<String>>((String? value) {
                        return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value!),
                         );
                       }).toList(),
                       ),
            Text("Shift", style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w500,
              color: Colors.white,
            )),
              DropdownButton(
                        value: dropdownShift,
                        onChanged: (String? value) {
                        setState(() {
                              dropdownShift = value;
                          });
                           },
                        items: shift.map<DropdownMenuItem<String>>((String? value) {
                        return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value!),
                         );
                       }).toList(),
                       ),
              Container(
                      width: MediaQuery.of(context).size.width / 1.4,
                      height: 45,
                      decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15.0),
                      color: Colors.white,
                       ),
                      child: MaterialButton(
                        onPressed: () async{
                        buses = await search(dropdownStationStart!,dropdownStationEnd!, dropdownShift!);
                        print("!");
                        print(buses);
                        //if bses [] dialog ot fod
                        Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => BusScreen(start:dropdownStationStart,end:dropdownStationEnd,shift: dropdownShift!),
                              ),
                            );
                      },
                        child: Text("Search"),
                       ),
                      )],
            ),
      ),
      
    );
  }
}