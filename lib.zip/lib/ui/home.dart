// ignore_for_file: prefer_const_constructors, avoid_print, unnecessary_new, use_key_in_widget_constructors

import 'package:flutter/material.dart';
import 'package:sit_user/net/flutterfire.dart';
import 'package:sit_user/ui/auth.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:location/location.dart';
import 'package:intl/intl.dart';
import 'package:rxdart/subjects.dart';
import 'package:sit_user/ui/cancelticket.dart';
import 'package:sit_user/ui/qrticket.dart';
import 'package:sit_user/ui/searchscreen.dart';
import 'package:sit_user/ui/stationscreen.dart';
import 'package:sit_user/ui/viewincoming.dart';

String? uid, email;
class HomeView extends StatefulWidget {
  const HomeView({ Key? key }) : super(key: key);

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  late LocationData _currentPosition;
  LatLng _initialcameraposition = LatLng(9.006992781288043, 38.84941534718417);
  Location location = Location();
   final Set<Marker> markers = {};  
  void getLoc() async{
    bool _serviceEnabled;
    PermissionStatus _permissionGranted;

    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }

    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }

    _currentPosition = await location.getLocation();
    _initialcameraposition = LatLng(_currentPosition.latitude!,_currentPosition.longitude!);
      markers.add(
                  Marker(
                    width: 80.0,
                    height: 80.0,
                    point: _initialcameraposition,
                    builder: (ctx) =>
                    Container(
                        child: Row(children: [IconButton(
                          icon: Icon(Icons.location_on),
                          
                          color: Colors.green, 
                          onPressed: () {  },
                        ),
                        SizedBox(width: 5,),
                        Text("You")]
                    )),
          ));
     // setMarkers();
    location.onLocationChanged.listen((LocationData currentLocation) {
      
      setState(() {
        _currentPosition = currentLocation;
        _initialcameraposition = LatLng(_currentPosition.latitude!,_currentPosition.longitude!);
         loading = false;
        DateTime now = DateTime.now();

      });
    });
     

  }
  @override
  void initState() {
    // TODO: implement initState
     
    super.initState();
    getLoc();
    getCurrentUser().then((user) {
      setState(() {
        uid = user?.uid;
        email = user?.email;
      });
    });
  }

   bool loading = true;

  @override
  Widget build(BuildContext context) {
      if(loading) {
       return Center(
                      child: CircularProgressIndicator(),
                  );
     }
    return Scaffold(
       appBar: AppBar(title: Text("Express Bus")),
       drawer: MyDrawerDirectory(),
       body: Stack(children: <Widget>[
          FlutterMap(
            options: MapOptions(
            center: _initialcameraposition,
            zoom: 18.0,
          ),
            layers: [
              TileLayerOptions(
                  urlTemplate: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                  subdomains: ['a', 'b', 'c'],
                  
              ),
              MarkerLayerOptions(
                  markers: markers.toList(),
              ),
          
    ],
  ),

       ]),
      
    );
  }
}

class MyDrawerDirectory extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(

      child:  Container(
      color: Colors.blue,
      child: Column (
        children: <Widget>[
        buildHeader(
              uid: FirebaseAuth.instance.currentUser != null? uid.toString():'',
              email: FirebaseAuth.instance.currentUser != null?email.toString():'',
              onClicked: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => HomeView()
              )),
            ),
          
        Expanded(
        child: ListView(
        children: [
          ListTile(leading: Icon(Icons.search), title: Text('Search for a Route'), onTap: () => _navPush(context, SearchScreen())),
          ListTile(leading: Icon(Icons.location_on),title: Text('Get Stations'), onTap: () => _navPush(context, StationScreen())),//AddPurchase( busId: "Bus1", busshift: "morning",))),
          if(FirebaseAuth.instance.currentUser != null)ListTile(leading: Icon(Icons.airplane_ticket),title: Text('My Ticket'), onTap: () => _navPush(context, QRticket())),
          if(FirebaseAuth.instance.currentUser != null)ListTile(leading: Icon(Icons.cancel), title: Text('Cancel Ticket'), onTap: () => _navPush(context,CancelTicket())),
          //ListTile(title: Text('Payment'), onTap: () => _navPush(context, Payment())),
          if(FirebaseAuth.instance.currentUser != null && hasUserPurchased())ListTile(leading: Icon(Icons.start), title: Text('Bus Status'), onTap: () async=> _navPush(context, ViewIncoming())),
          FirebaseAuth.instance.currentUser != null? 
          ListTile(leading: Icon(Icons.logout),title: Text('Log Out'), onTap: () async { 
                      await FirebaseAuth.instance.signOut(); runApp(
                      new MaterialApp(
                         home: HomeView(),
                        ));}):
          ListTile(leading: Icon(Icons.login),title: Text('Log In'), onTap: () async {runApp(
                      new MaterialApp(
                        home: Auth(),
                        )

  );},
        
          )],
      )),
        ])));
  }

  Future<dynamic> _navPush(BuildContext context, Widget page) {
    return Navigator.push(context, MaterialPageRoute(
      builder: (context) => page,
    ));
  }
}

  Widget buildHeader({
    required String uid,
    //required String urlImage,
    required String email,
    required VoidCallback onClicked,
  }) =>
      InkWell(
        onTap: onClicked,
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 40),
          child: Row(
            children: [
             // CircleAvatar(radius: 30, backgroundImage: NetworkImage(urlImage)),
              SizedBox(width: 20),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    uid,
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    email,
                    style: TextStyle(fontSize: 14, color: Colors.white),
                  ),
                ],
              ),
              Spacer(),
              CircleAvatar(
                radius: 24,
                backgroundColor: Color.fromRGBO(30, 60, 168, 1),
                child: Icon(Icons.add_comment_outlined, color: Colors.white),
              )
            ],
          ),
        ),
      );

