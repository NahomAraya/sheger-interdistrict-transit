// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:location/location.dart';
import 'package:sit_user/net/networking.dart';
import 'package:sit_user/ui/searchscreen.dart';
import '../net/flutterfire.dart';

class LineString {
  LineString(this.lineString);
  List<dynamic> lineString;
}

class ViewIncoming extends StatefulWidget {
  const ViewIncoming({ Key? key }) : super(key: key);

  @override
  State<ViewIncoming> createState() => _ViewIncomingState();
}

class _ViewIncomingState extends State<ViewIncoming> {
  late LocationData _currentPosition;
  LatLng _initialcameraposition = LatLng(9.006992781288043, 38.84941534718417);
  Location location = Location();
  final List<LatLng> polyPoints = []; 

  final Set<Polyline> polyLines = {};

  final Set<Marker> markers = {};

  var data;
  late GeoPoint s;
  late GeoPoint e;

  String uid = FirebaseAuth.instance.currentUser!.uid;

  double startLat = 9.006992781288043;

  double startLng = 38.84941534718417;

  double endLat = 9.020272; 

  double endLng = 38.852366;

  double userLat = 0.0;

  double userLng = 0.0;
  bool loading = true;

  void getLoc() async{
    bool _serviceEnabled;
    PermissionStatus _permissionGranted;

    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }

    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }

    _currentPosition = await location.getLocation();
    _initialcameraposition = LatLng(_currentPosition.latitude!,_currentPosition.longitude!);
      markers.add(
                  Marker(
                    width: 80.0,
                    height: 80.0,
                    point: _initialcameraposition,
                    builder: (ctx) =>
                    Row(children: [IconButton(
                      icon: Icon(Icons.location_on),
                      
                      color: Colors.green, 
                      onPressed: () {  },
                    ),
                    SizedBox(width: 5,),
                    Text("You")]
                    ),
          ));
     // setMarkers();
    location.onLocationChanged.listen((LocationData currentLocation) {
      
      setState(() {
        _currentPosition = currentLocation;
        _initialcameraposition = LatLng(_currentPosition.latitude!,_currentPosition.longitude!);
         loading = false;
        DateTime now = DateTime.now();

      });
    });
     

  }
    void initMarker(specify, specifyId) async {
    var markerIdVal = specifyId;
    bool max = await maxCapacity(specifyId);
    //final MarkerId markerId = MarkerId(markerIdVal);
    final Marker marker = Marker(
       width: 80.0,
                    height: 80.0,
                    point: LatLng(specify['location'].latitude, specify['location'].longitude),
                    builder: (ctx) => max?
                    IconButton(
                      icon: Icon(Icons.bus_alert),
                      color: Colors.blue, 
                      onPressed: () {  },
                    ):IconButton(
                      icon: Icon(Icons.bus_alert),
                      color: Colors.red, 
                      onPressed: () {  },
                    ),
    );
    setState(() {
      markers.add(marker);
      //print(markerId);
    });
  }


  getMarkerData() async{
      FirebaseFirestore.instance.collection('buses')
        .where(FieldPath.documentId, whereIn: buses)
        .get()
        .then((QuerySnapshot querySnapshot) {
      for (var doc in querySnapshot.docs) {
        initMarker(doc.data(), doc.id);
      }
    });
  }
 

  
    void getJsonData() async {
        FirebaseFirestore.instance
    .collection('User')
    .doc(uid)
    .get()
    .then((DocumentSnapshot documentSnapshot) {
      if (documentSnapshot.exists) {//add null check
      setState(() async {
          s = (await getStation(documentSnapshot["start_station"].toString()))!;
          e = (await getStation(documentSnapshot["end_station"].toString()))!;
      });}
    });
       

    startLat = s.latitude;
    //userLat = userloc!.latitude;
    //print(userLat);
    //userLng = userloc.longitude;
    startLng = s.longitude;
    endLat = e.latitude;
    endLng = e.longitude;
    NetworkHelper network = NetworkHelper(
      startLat: startLat,
      startLng: startLng,
      endLat: endLat,
      endLng: endLng,
      
    );
    

    try {
      // getData() returns a json Decoded data
      data = await network.getData();

      // We can reach to our desired JSON data manually as following
      LineString ls =
          LineString(data['features'][0]['geometry']['coordinates']);

      for (int i = 0; i < ls.lineString.length; i++) {
        polyPoints.add(LatLng(ls.lineString[i][1], ls.lineString[i][0]));
      }

      if (polyPoints.length == ls.lineString.length) {
        setPolyLines();
        setState((){ loading = false; });
      }
    } catch (e) {
      print(e);
    }

    }
    setPolyLines() {
      Polyline polyline = Polyline(
      color: Colors.lightBlue,
      points: polyPoints,
      strokeWidth: 8
    );
    polyLines.add(polyline);
  }
   @override
   initState() {
    //map here
    super.initState();
    print("iit");
    getLoc();
    getJsonData();
    getMarkerData();
    
  }
  @override
  Widget build(BuildContext context) {
    if(loading) {
       return Center(
                      child: CircularProgressIndicator(),
                  );
     }
    return Scaffold(
      appBar: AppBar(title: Text("Express Bus")),
      body: Stack(children: <Widget>[
          FlutterMap(
            options: MapOptions(
            center: _initialcameraposition,
            zoom: 18.0,
          ),
            layers: [
              TileLayerOptions(
                  urlTemplate: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                  subdomains: ['a', 'b', 'c'],
                  
              ),
              MarkerLayerOptions(
                  markers: markers.toList(),
              ),
               PolylineLayerOptions(
                  polylines: polyLines.toList(),
              )
          ],
        ),

       ]),
      
    );
  }
}