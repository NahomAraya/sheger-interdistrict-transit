// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:sit_user/net/flutterfire.dart';
import 'package:sit_user/net/networking.dart';
import 'package:geoflutterfire/geoflutterfire.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:sit_user/ui/searchscreen.dart';

class LineString {
  LineString(this.lineString);
  List<dynamic> lineString;
}
class BusRoute extends StatefulWidget {
  final String? busid;
  final String? shift;
  
  BusRoute({ this.busid, this.shift, Key? key  }) : super(key: key);

  @override
  State<BusRoute> createState() => _BusRouteState();
}

class _BusRouteState extends State<BusRoute> {
  final List<LatLng> polyPoints = []; 

  final Set<Polyline> polyLines = {};

  final Set<Marker> markers = {};

  late final List route;
  var data;

  double startLat = 9.006992781288043;

  double startLng = 38.84941534718417;

  double endLat = 9.020272; 

  double endLng = 38.852366;

  double busLat = 0.0;

  double busLng = 0.0;
  void getJsonData() async {
    print("getting route");
    route = await getRoute(widget.busid, widget.shift);
    // Create an instance of Class NetworkHelper which uses http package
    // for requesting data to the server and receiving response as JSON format
    
    //List<String> route = <String>[];
    //DocumentSnapshot documentSnapshot = FirebaseFirestore.instance.collection('bus').doc(bus) as DocumentSnapshot<Object?>;
    
    int arrayLength=route.length;
   // var u = getStation(fromField.text);
    var s = getStation(route[0]);
    var e = getStation(route[arrayLength-1]);
    
    GeoPoint?startloc = await s;
    GeoPoint? endloc = await e;
     
   // GeoPoint? userloc = await u;

    startLat = startloc!.latitude;
    //userLat = userloc!.latitude;
    //print(userLat);
    //userLng = userloc.longitude;
    startLng = startloc.longitude;
    endLat = endloc!.latitude;
    endLng = endloc.longitude;
    NetworkHelper network = NetworkHelper(
      startLat: startLat,
      startLng: startLng,
      endLat: endLat,
      endLng: endLng,
      
    );
    

    try {
      // getData() returns a json Decoded data
      data = await network.getData();

      // We can reach to our desired JSON data manually as following
      LineString ls =
          LineString(data['features'][0]['geometry']['coordinates']);

      for (int i = 0; i < ls.lineString.length; i++) {
        polyPoints.add(LatLng(ls.lineString[i][1], ls.lineString[i][0]));
      }

      if (polyPoints.length == ls.lineString.length) {
        setPolyLines();
        setState((){ loading = false; });
      }
    } catch (e) {
      print(e);
    }
  }
  setPolyLines() {
      Polyline polyline = Polyline(
      color: Colors.lightBlue,
      points: polyPoints,
      strokeWidth: 8
    );
    polyLines.add(polyline);
  }
  void initMarker(specify, specifyId) async {
    var markerIdVal = specifyId;
    bool max = await maxCapacity(specifyId);
    print(max);
    //final MarkerId markerId = MarkerId(markerIdVal);
    final Marker marker = Marker(
       width: 80.0,
                    height: 80.0,
                    point: LatLng(specify['location'].latitude, specify['location'].longitude),
                    builder: (ctx) => max?
                    IconButton(
                      icon: Icon(Icons.bus_alert),
                      color: Colors.blue, 
                      onPressed: () {  },
                    ):IconButton(
                      icon: Icon(Icons.bus_alert),
                      color: Colors.red, 
                      onPressed: () {  },
                    ),
    );
    setState(() {
      markers.add(marker);
      //print(markerId);
    });
  }


  getMarkerData() async{
      FirebaseFirestore.instance.collection('buses')
        .where(FieldPath.documentId, whereIn: buses)
        .get()
        .then((QuerySnapshot querySnapshot) {
      for (var doc in querySnapshot.docs) {
        initMarker(doc.data(), doc.id);
      }
    });
  }
  getBusLocation()async{
    GeoPoint? location;
    await FirebaseFirestore.instance
                 .collection("buses")
                 .doc(widget.busid).
                 get().then((snapshot) {
      location = snapshot.get('location');
      
    });
    busLat = location!.latitude;
    busLng = location!.longitude;
  } 
   bool loading = true;
   @override
   initState() {
    //map here
    super.initState();
  
    getJsonData();
    getBusLocation();
    getMarkerData();
    
  }
  @override
  Widget build(BuildContext context) {
    if(loading) {
       return Center(
                      child: CircularProgressIndicator(),
                  );
     }
    return Scaffold(
      appBar: AppBar(title: Text("Express Bus")),
      body: FlutterMap(
            options: MapOptions(
            center: LatLng(busLat,busLng),
            zoom: 18.0,
          ),
            layers: [
              TileLayerOptions(
                  urlTemplate: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                  subdomains: ['a', 'b', 'c'],
                  
              ),
              MarkerLayerOptions(
                  markers: [
                  Marker(
                    width: 80.0,
                    height: 80.0,
                    point: LatLng(busLat, busLng),
                    builder: (ctx) =>
                    Container(
                        child: IconButton(
                          icon: Icon(Icons.location_on),
                          color: Colors.green, 
                          onPressed: () {  },
                        ),
                    ),
          ),
                  
                  Marker(
                    width: 80.0,
                    height: 80.0,
                    point: LatLng(startLat, startLng),
                    builder: (ctx) =>
                    Container(
                        child: IconButton(
                          icon: Icon(Icons.location_on),
                          color: Colors.red, 
                          onPressed: () {  },
                        ),
                    ),
          ),
            Marker(
                    width: 80.0,
                    height: 80.0,
                    point: LatLng(endLat, endLng),
                    builder: (ctx) =>
                    Container(
                        child: IconButton(
                          icon: Icon(Icons.location_on),
                          color: Colors.red, 
                          onPressed: () {  },
                        ),
                    ),
          )
        ],
      ),
      PolylineLayerOptions(
        polylines: polyLines.toList(),

      )
    ],
  )
,
      
    );
  }
}