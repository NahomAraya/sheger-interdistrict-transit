// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:location/location.dart';
import 'package:sit_user/net/flutterfire.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';


class StationScreen extends StatefulWidget {
  const StationScreen({ Key? key }) : super(key: key);

  @override
  State<StationScreen> createState() => _StationScreenState();
}

class _StationScreenState extends State<StationScreen> {
  late LocationData _currentPosition;
  Location location = Location();
  late final nameList;
  var busList;
  bool dataisthere = false;
  getStation() async{
      _currentPosition = await location.getLocation();
      nameList= FirebaseFirestore.instance
        .collection('stations')
        
        .snapshots();
      
   
    // var documents = await FirebaseFirestore.instance
    //     .collection('bus')
    //     .where(FieldPath.documentId, whereIn: buses)
    //     .get();
    setState(() {
      
      dataisthere = true;
      
    });

  }
   @override
  void initState() {
    super.initState();
    
    //busList= widget.buses; 
    getStation();
  
    
  } 
  @override
  Widget build(BuildContext context) {
    return dataisthere == false ? Scaffold(body: Center(child: CircularProgressIndicator())):
    Scaffold(
      appBar: AppBar(
        title: Text('Express Bus'),
      ),
      body: StreamBuilder<QuerySnapshot>(
            stream: nameList,
            builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot){
            
            if(snapshot.connectionState == ConnectionState.done){
                return Center(
                      child: CircularProgressIndicator(),
                  );
            }
            
          else{  
           if(!snapshot.hasData){
              return Center(
                      child: CircularProgressIndicator(),
                  );
            }
          if (nameList!=[]) {
          return ListView(
              children: snapshot.data!.docs.map((document) {
               
              return Center(
                   child:calculateDistance(_currentPosition.latitude!,_currentPosition.longitude!,document['Location'].latitude!,document['Location'].longitude!) < 2.0 ?  Container(
                        width: MediaQuery.of(context).size.width / 1.2,
                        height: MediaQuery.of(context).size.height / 6,
                        child: Column(children: [
                          Text("Station Name: " + document['Name']),
                          ElevatedButton(
                            onPressed: () {
                                Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => Stationmap(document["Location"].latitude,document["Location"].longitude)//AddPurchase(document.refernce.id),
                                  ),
                            );
                         },
                            style: ElevatedButton.styleFrom(
                                primary: Colors.blue,
                                onPrimary: Colors.black
                                  ),
                            child: Text('View on Map')
                            ),
                          
                          
                    
                          
                        ],) 
                        
              ):Container()
                        

          );
        }).toList(),
      );}
      else{
         return Center(
                child: Padding(
                  padding:const EdgeInsets.fromLTRB(0, 100, 0, 0),
                        child: Container(
                          child: Text("No Staions Avalible",style: TextStyle(
                                          fontSize: 18, color: Colors.black),
                                    ))));
      }
    }}
  ),
    );

  }
}

class Stationmap extends StatefulWidget {
  final double StationLat;
  final double StationLng;
  Stationmap(this.StationLat, this.StationLng, { Key? key}) : super(key: key);

  @override
  State<Stationmap> createState() => _StationmapState();
}

class _StationmapState extends State<Stationmap> {
  double lat = 0.0;
  double lng = 0.0;
  @override
   initState() {
    //map here
    super.initState();
    lat = widget.StationLat;
    lng = widget.StationLng;
    setState(() {
      loading=false;
    });

    
    
  }
  bool loading = true;
  @override
  Widget build(BuildContext context) {
    print("ap");
     if(loading) {
       return Center(
                      child: CircularProgressIndicator(),
                  );
     }
     return Scaffold(
       body:FlutterMap(
            options: MapOptions(
            center: LatLng(widget.StationLat,widget.StationLng),
            zoom: 18.0,
          ),
            layers: [
              TileLayerOptions(
                  urlTemplate: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                  subdomains: ['a', 'b', 'c'],
                  
              ),
              MarkerLayerOptions(
                  markers: [
                  Marker(
                    width: 80.0,
                    height: 80.0,
                    point: LatLng(widget.StationLat, widget.StationLng),
                    builder: (ctx) =>
                    Container(
                        child: IconButton(
                          icon: Icon(Icons.location_on),
                          color: Colors.green, 
                          onPressed: () {  },
                        ),
                    ),
          ),])

            ]));
  }
}