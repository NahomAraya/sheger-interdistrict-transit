// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:sit_user/ui/auth.dart';
import 'package:sit_user/ui/home.dart';
import 'package:splashscreen/splashscreen.dart';
import 'dart:async';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}


class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late StreamSubscription<User?> user;
  @override
  void initState() {
    super.initState();
    user = FirebaseAuth.instance.authStateChanges().listen((user) {
      if (user == null) {
        print('User is currently signed out!');
      } else {
        print('User is signed in!');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplashScreen(
      seconds: 6,//FirebaseAuth.instance.currentUser == null? Auth():
      navigateAfterSeconds:  HomeView(), 
      title: Text('Welcome to SIT', style:TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 20.0,
              color: Colors.white),
        ),
      image: Image.asset('assets/images/Expresslogo.jpg'),
      loadingText: Text("Loading"),
      backgroundColor: Colors.blue,
      photoSize: 100.0,
      loaderColor: Colors.blue,
    )
    );
  }
}