import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

Future<bool> signIn(String email, String password) async {
  try {
    await FirebaseAuth.instance
        .signInWithEmailAndPassword(email: email, password: password);
    return true;
  } catch (e) {
    print(e);
    return false;
  }
}

Future<bool> register(String email, String password) async {
  try {
    await FirebaseAuth.instance
        .createUserWithEmailAndPassword(email: email, password: password);
    return true;
  } on FirebaseAuthException catch (e) {
    if (e.code == 'weak-password') {
      print('The password provided is too weak.');
    } else if (e.code == 'email-already-in-use') {
      print('The account already exists for that email.');
    }
    return false;
  } catch (e) {
    print(e.toString());
    return false;
  }
}
Future<User?> getCurrentUser() async {
    return FirebaseAuth.instance.currentUser;
}

Future<List> search(String from, String to, String shift) async{
  List avalilbleBuses = [];
  String busId = "";
  List busRoute = [];
  await FirebaseFirestore.instance.collection("buses").get().then((querySnapshot) async {
  for (var result in querySnapshot.docs) {
     busId = result.id.toString();
     await FirebaseFirestore.instance
                .collection("buses")
                .doc(busId)
                .collection("shifts")
                .get()
                .then((querySnapshot) async {
                    for (var result in querySnapshot.docs) {
                      if(result.data()["name"] == shift){
                        busRoute = result.data()["routePath"]; 
                        //   var routeid = result.data()["route"];
                        //   await FirebaseFirestore.instance.collection("routes").doc(routeid.toString()).get().then((querySnapshot) {
                        //          if(querySnapshot.exists){
                        //             print('Document exists');
                        //             busRoute = querySnapshot.get("route");
                        //          }
                                 
                             
                        // });
                        print(busRoute);
                        if(busRoute.contains(from) && busRoute.contains(to)){
                            if(busRoute.indexOf(from) < busRoute.indexOf(to)){
                      
                                    avalilbleBuses.add(busId);
                            }}                      
                     
                      
                      }
                    }
                  });
  }});

    print(avalilbleBuses);
    return avalilbleBuses;
}
Future<String?> getCapacity(busid) async{
   int? passengers;
   await FirebaseFirestore.instance
                 .collection("buses")
                 .doc(busid)
                 
                 //.doc(shift)
                 .get()
                 .then((querySnapshot) {
                   passengers = querySnapshot.get("passengers");
                 });
   
  print(passengers);
  return passengers.toString();

}
Future<bool> maxCapacity(busid) async{
  
   int? passengers;
   int? capacity;
   await FirebaseFirestore.instance
                 .collection("buses")
                 .doc(busid)
                  .get()
                 .then((querySnapshot) {
                   capacity= querySnapshot.get("capacity");
                   passengers = querySnapshot.get("passengers");
                 });
  
  return (capacity!>=passengers!);

}
Future<List> getRoute(busid, shift) async{
  List route=[];
  
   await FirebaseFirestore.instance
                 .collection("buses")
                 .doc(busid)
                 .collection("shifts")
                 
                 .get()
                 .then((querySnapshot) {
                   for(var result in querySnapshot.docs){
                     if(result.data()["name"] == shift){
                     route=result.data()["routePath"];
                     }
                   }
                 });
  
  return route;

}
Future<GeoPoint?> getStation(String doc) async{
  
   
   DocumentReference documentReference = FirebaseFirestore.instance
                 .collection("stations")
                 .doc(doc);
   GeoPoint? location;
   

    await documentReference.get().then((snapshot) {
      location = snapshot.get('Location');
      
    });
    print(location!.latitude);
    return location;
  
                     
   }
  Future<bool> purchaseRoute(String from, String to, double fare) async {
    try {
    String uid = FirebaseAuth.instance.currentUser!.uid;
    DocumentReference userref = FirebaseFirestore.instance
        .collection('User')
        .doc(uid);
     
    FirebaseFirestore.instance.collection("User").doc(uid).get()
    .then((docSnapshot) async => {
    if (docSnapshot.exists) {
        // if(await isBusAvalible(bus, busshift)){
        //   throw("Bus at max capacity")
        // }
        // else{
       // double cur_token = docSnapshot.get('tokens') - fare,
        if (docSnapshot.get("token") >= fare ) {
                    await FirebaseFirestore.instance.collection("User").doc(uid).update({
                          'start_station':from,
                          'end_station': to,
                          
        },
        ).then((value) => print("Ticket Purchased"))//check this with the bus route
        .catchError((error) => print("Failed to book bus: $error"))   
      
        }
        else{
          throw("You have already booked a ticket. Cancel your current booking first")
        }
      
    } else {
        // docSnapshot.data() will be undefined in this case
        throw("No such User!")
    }
    }).catchError((error) => 
      print("Error getting user: $error")
);
FirebaseFirestore.instance.runTransaction((transaction) async {
      DocumentSnapshot snapshot1 = await transaction.get(userref);
     
      double cut_pass = snapshot1.get('token') - fare;
      transaction.update(userref, {'token': cut_pass });
      return true;
    });
 return true;
  } catch (e) {
    return false;
  }
  

  }
  bool hasUserPurchased(){
      bool purchased = false;
      String uid = FirebaseAuth.instance.currentUser!.uid;
       FirebaseFirestore.instance.collection("User").doc(uid).get()
    .then((docSnapshot) async => {
    if (docSnapshot.exists) {
        if (docSnapshot.get("start_station") != "") {
           // Bio is empty
            
             purchased=true
        }
        else{
          print("naniiii")
        }
    } else {
        // docSnapshot.data() will be undefined in this case
        print("No such User!")
    }
    }).catchError((error) => 
      print("Error getting user: $error")
);
  return purchased;
  }

  double calculateDistance(lat1, lon1, lat2, lon2){
    var p = 0.017453292519943295;
    var c = cos;
    var a = 0.5 - c((lat2 - lat1) * p)/2 + 
          c(lat1 * p) * c(lat2 * p) * 
          (1 - c((lon2 - lon1) * p))/2;
    
    return 12742 * asin(sqrt(a));
  }
  Future<double> calculateFare(String start, String end) async {
     GeoPoint? s = await getStation(start);
     GeoPoint? e = await getStation(end);
     return calculateDistance(s!.latitude, s.longitude, e!.latitude, e.longitude) * 1.5;

  }

Future<void> cancelRoute(uid) async{
    print(uid);
   
    await FirebaseFirestore.instance.collection("User").doc(uid).update({
          'start_station': "",
          'end_station': ""
        },
        ).then((value) => print("Route canceled"))
        .catchError((error) => print("Failed to cancel bus: $error"));

  }